package edu.citytech.games.c4.service;

public class Connect4Service {

	public static int getValidCellMoves(String[] moves, int i) {
		// TODO Auto-generated method stub
		return 0;
	}

	public static int[] getWinner(String[] moves) {
		int[] winningCombo = new int[] {};
		
//TestWinner_Row1
//test1	
		if(moves[0].equals("X") && moves[1].equals("X") 
				&& moves[2].equals("X") && moves[3].equals("X")) {			
			winningCombo = new int[] {0, 1, 2, 3};
			
		}
		
		else if (moves[0].equals("O") && moves[1].equals("O") 
				&& moves[2].equals("O") && moves[3].equals("O")){
			winningCombo = new int[] {0, 1, 2, 3};
			
		}
//test2
		
		else if(moves[1].equals("X") && moves[2].equals("X") 
				&& moves[3].equals("X") && moves[4].equals("X")) {			
			winningCombo = new int[] {1, 2, 3, 4};
			
		}
		
		else if (moves[1].equals("O") && moves[2].equals("O") 
				&& moves[3].equals("O") && moves[4].equals("O")){
			winningCombo = new int[] {1, 2, 3, 4};
			
		}
//test3
		
		else if(moves[2].equals("X") && moves[3].equals("X") 
				&& moves[4].equals("X") && moves[5].equals("X")) {			
			winningCombo = new int[] {2, 3, 4, 5};
			
		}
		
		else if (moves[2].equals("O") && moves[3].equals("O") 
				&& moves[4].equals("O") && moves[5].equals("O")){
			winningCombo = new int[] {2, 3, 4, 5};
			
		}	
//Test4
		else if(moves[3].equals("X") && moves[4].equals("X") 
				&& moves[5].equals("X") && moves[6].equals("X")) {			
			winningCombo = new int[] {3, 4, 5, 6};
			
		}
		
		else if (moves[3].equals("O") && moves[4].equals("O") 
				&& moves[5].equals("O") && moves[6].equals("O")){
			winningCombo = new int[] {3, 4, 5, 6};
			
		}
//Test 5
		else if(moves[7].equals("X") && moves[8].equals("X") 
				&& moves[9].equals("X") && moves[10].equals("X")) {			
			winningCombo = new int[] {7, 8, 9, 10};
			
		}
		
		else if (moves[7].equals("O") && moves[8].equals("O") 
				&& moves[9].equals("O") && moves[10].equals("O")){
			winningCombo = new int[] {7, 8, 9, 10};
			
		}
//Test 6		
		else if(moves[8].equals("X") && moves[9].equals("X") 
				&& moves[10].equals("X") && moves[11].equals("X")) {			
			winningCombo = new int[] {8, 9, 10, 11};
			
		}
		
		else if (moves[8].equals("O") && moves[9].equals("O") 
				&& moves[10].equals("O") && moves[11].equals("O")){
			winningCombo = new int[] {8, 9, 10, 11};
			
		
		}
//Test 7		
		else if(moves[9].equals("X") && moves[10].equals("X") 
				&& moves[11].equals("X") && moves[12].equals("X")) {			
			winningCombo = new int[] {9, 10, 11, 12};
			
		}
		
		else if (moves[9].equals("O") && moves[10].equals("O") 
				&& moves[11].equals("O") && moves[12].equals("O")){
			winningCombo = new int[] {9, 10, 11, 12};
			
		
		}
//Test 8
		else if(moves[10].equals("X") && moves[11].equals("X") 
				&& moves[12].equals("X") && moves[13].equals("X")) {			
			winningCombo = new int[] {10, 11, 12, 13};
			
		}
		
		else if (moves[10].equals("O") && moves[11].equals("O") 
				&& moves[12].equals("O") && moves[13].equals("O")){
			winningCombo = new int[] {10, 11, 12, 13};
			
		
		}
//Test 9
		else if(moves[14].equals("X") && moves[14].equals("X") 
				&& moves[15].equals("X") && moves[16].equals("X")) {			
			winningCombo = new int[] {14, 15, 16, 17};
			
		}
		
		else if (moves[14].equals("O") && moves[15].equals("O") 
				&& moves[16].equals("O") && moves[17].equals("O")){
			winningCombo = new int[] {14, 15, 16, 17};
			
		}
//Test 10
		else if(moves[15].equals("X") && moves[16].equals("X") 
				&& moves[17].equals("X") && moves[18].equals("X")) {			
			winningCombo = new int[] {15, 16, 17, 18};
			
		}
		
		else if (moves[15].equals("O") && moves[16].equals("O") 
				&& moves[17].equals("O") && moves[18].equals("O")){
			winningCombo = new int[] {15, 16, 17, 18};
			
		}
//Test 11
		else if(moves[16].equals("X") && moves[17].equals("X") 
				&& moves[18].equals("X") && moves[19].equals("X")) {			
			winningCombo = new int[] {16, 17, 18, 19};
			
		}
		
		else if (moves[16].equals("O") && moves[17].equals("O") 
				&& moves[18].equals("O") && moves[19].equals("O")){
			winningCombo = new int[] {16, 17, 18, 19};
			
		}
		
//Test 12
		else if(moves[17].equals("X") && moves[18].equals("X") 
				&& moves[19].equals("X") && moves[20].equals("X")) {			
			winningCombo = new int[] {17, 18, 19, 20};
			
		}
		
		else if (moves[17].equals("O") && moves[18].equals("O") 
				&& moves[19].equals("O") && moves[20].equals("O")){
			winningCombo = new int[] {17, 18, 19, 20};
			
		}
		
//Test 13
		else if(moves[21].equals("X") && moves[22].equals("X") 
				&& moves[23].equals("X") && moves[24].equals("X")) {			
			winningCombo = new int[] {21, 22, 23, 24};
			
		}
		
		else if (moves[21].equals("O") && moves[22].equals("O") 
				&& moves[23].equals("O") && moves[24].equals("O")){
			winningCombo = new int[] {21, 22, 23, 24};
			
		}
//Test 14
		else if(moves[22].equals("X") && moves[23].equals("X") 
				&& moves[24].equals("X") && moves[25].equals("X")) {			
			winningCombo = new int[] {22, 23, 24, 25};
			
		}
	
		else if (moves[22].equals("O") && moves[23].equals("O") 
				&& moves[24].equals("O") && moves[25].equals("O")){
			winningCombo = new int[] {22, 23, 24, 25};
			
		}
//Test 15		
		else if(moves[23].equals("X") && moves[24].equals("X") 
				&& moves[25].equals("X") && moves[26].equals("X")) {			
			winningCombo = new int[] {23, 24, 25, 26};
			
		}
	
		else if (moves[23].equals("O") && moves[24].equals("O") 
				&& moves[25].equals("O") && moves[26].equals("O")){
			winningCombo = new int[] {23, 24, 25, 26};
			
		}
//Test 16		
		else if(moves[24].equals("X") && moves[25].equals("X") 
				&& moves[26].equals("X") && moves[27].equals("X")) {			
			winningCombo = new int[] {24, 25, 26, 27};
			
		}
	
		else if (moves[24].equals("O") && moves[25].equals("O") 
				&& moves[26].equals("O") && moves[27].equals("O")){
			winningCombo = new int[] {24, 25, 26, 27};
			
		}
//Test 17		
		else if(moves[28].equals("X") && moves[29].equals("X") 
				&& moves[30].equals("X") && moves[31].equals("X")) {			
			winningCombo = new int[] {28, 29, 30, 31};
			
		}
	
		else if (moves[28].equals("O") && moves[29].equals("O") 
				&& moves[30].equals("O") && moves[31].equals("O")){
			winningCombo = new int[] {28, 29, 30, 31};
			
		}
//Test 18			
		else if(moves[29].equals("X") && moves[30].equals("X") 
				&& moves[31].equals("X") && moves[32].equals("X")) {			
			winningCombo = new int[] {29, 30, 31, 32};
			
		}

		else if (moves[29].equals("O") && moves[30].equals("O") 
				&& moves[31].equals("O") && moves[32].equals("O")){
			winningCombo = new int[] {29, 30, 31, 32};
			
		}
//Test 19		
		else if(moves[30].equals("X") && moves[31].equals("X") 
				&& moves[32].equals("X") && moves[33].equals("X")) {			
			winningCombo = new int[] {30, 31, 32, 33};
			
		}

		else if (moves[30].equals("O") && moves[31].equals("O") 
				&& moves[32].equals("O") && moves[33].equals("O")){
			winningCombo = new int[] {30, 31, 32, 33};
			
		}
//Test 20
		else if(moves[31].equals("X") && moves[32].equals("X") 
				&& moves[33].equals("X") && moves[34].equals("X")) {			
			winningCombo = new int[] {31, 32, 33, 34};
			
		}

		else if (moves[31].equals("O") && moves[32].equals("O") 
				&& moves[33].equals("O") && moves[34].equals("O")){
			winningCombo = new int[] {31, 32, 33, 34};
			
		}
		return winningCombo;
	}



	
		
}
